#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <ctime>

using namespace std;

class user
{
private:
    string username, password, email;
    string phone_no;

public:
    user() {}
    user(string name, string pass)
    {
        username = name;
        password = pass;
    }
    user(string name, string pass, string mail, string no)
    {
        username = name;
        password = pass;
        email = mail;
        phone_no = no;
    }
    int silver_customer(int cloth_prices)
    {
        cout << "     you comes in silver customer catagory so you got 15 percent discount  \n";
        cloth_prices = (cloth_prices - 15) / 100;
        return cloth_prices;
    }
    int gold_customer(int cloth_prices)
    {
        cout << "    you comes in gold customer catagory so you got 7 percent discount    \n";
        cloth_prices = (cloth_prices - 7) / 100;
        return cloth_prices;
    }
    int platinum_customer(int cloth_prices)
    {
        cout << "    you comes in platinum customer catagory so you got 3 percent discount     \n";
        cloth_prices = (cloth_prices - 3) / 100;
        return cloth_prices;
    }
};
struct abc
{
    string username;
    string password;
    string fabric_type;
    string cloth_color;
};
bool check_cloth_Exists(const string &fabric_type, const string &cloth_color, const char &cloth_size)
{
    abc users;
    ifstream reading("data.txt");
    while (reading >> users.fabric_type >> users.cloth_color)
    {
        // Check if the entered type,color,size matches any type,color,size in the file
        if (fabric_type == users.fabric_type && cloth_color == users.cloth_color)
        {
            return true; // qualities exist
        }
    }

    return false; // qualities does not exist
}
void saveDataToFile(const abc &users, ofstream &outputFile)
{
    // Save user data to the file
    outputFile << users.username << " " << users.password << endl;
}
bool check_Username_Exists(const string &username, const string &password)
{
    abc users;
    ifstream reading("customer.txt");
    while (reading >> users.username >> users.password)
    {
        // Check if the entered username matches any username in the file
        if (username == users.username && password == users.password)
        {
            return true; // Username exists
        }
    }

    return false; // Username does not exist
}
//////////////////////////////////////
class usermanager
{
private:
    vector<user> users;

public:
    void log_in_user()
    {
        string username, password;

        cout << "\t\tEnter user name to login : ";
        cin >> username;
        cout << "\t\tEnter password : ";
        cin >> password;
        if (check_Username_Exists(username, password))
        {
            cout << "\t\tLogged in successfully" << endl;
        }
        else
        {
            cout << "\t\tInvalid Username or password" << endl;
            log_in_user();
        }
    }
    void registerUser()
    {
        int c = 0; // flag
        string username, password, email;
        string phone_no;
        ofstream writing("customer.txt", ios::app);
        cout << "\nEnter user name : ";
        cin >> username;
        cout << "\nEnter password : ";
        cin >> password;
        cout << "\nEnter your email : ";
        cin >> email;
        email += "@gmail.com";
        cout << "show full email: " << email;

        cout << "\nEnter your phone number :";
        cin >> phone_no;
        for (int i = 0; i < phone_no.size(); i++)
        {
            if (!isdigit(phone_no[i]))
            {
                c = 1;
                break;
            }
        }
        if (c == 1)
        {
            cout << "\nEnter phone_number in numeric form: ";
            cin >> phone_no;
        }
        writing << username << " " << password << " " << email << " " << phone_no << endl;
        writing.close();
        ifstream inFile("customer.txt");

        user newuser(username, password, email, phone_no);
        users.push_back(newuser);
        cout << "\t\tUser registered successfully............" << endl;
    }
};
////////////////////////////
class cloth
{
protected:
    int product_id;
    string cloth_name;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    virtual void set_info()
    {
        cout << " product id :";
        cin >> product_id;
        cout << "enter cloth name:  ";
        cin >> cloth_name;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size:  ";
        cin >> cloth_size;
        cout << "cloth price:  ";
        cin >> cloth_price;
        cout << " quantity of that cloth: ";
        cin >> stock_quantity;
    }
};
///////////////////////////////////////
class order : public cloth
{
protected:
    string username;
    time_t time_stamp;
    string shipping_address;
    int payment_method;

public:
    order() {}

    void setUsername(const string &name)
    {
        username = name;
    }
    void get_data1()
    {
        cout << "Enter your address : " << endl;
        cin >> shipping_address;
        cout << "Enter 1 for COD or 2 for online payment : " << endl;
        cin >> payment_method;
    }
    void display()
    {
        cout << "Your order info is" << endl;
        cout << "Address : " << shipping_address << "\ntime : " << ctime(&time_stamp) << endl;
    }
    void confirm_Payment()
    {
        int orderID = rand() % 10000 + 1;

        cout << "Payment confirmed. Thank you for your order!" << endl;
        cout << "Order ID: " << orderID << endl;

        stock_quantity--;

        ofstream orderFile("order_history.txt", ios::app);
        if (orderFile.is_open())
        {
            orderFile << "Order ID: " << orderID << "\n";
            orderFile << "Address: " << shipping_address << "\n";
            orderFile << "Time: " << ctime(&time_stamp) << "\n";
            orderFile << "-----------------------\n";
            orderFile.close();
        }
        else
        {
            cout << "Error opening file to store order details!" << endl;
        }
    }
    void save_Cart_Items_To_File(const string &username, string cloth_name, string cloth_color, char cloth_size, int stock_quantity)
    {
        ofstream cartFile(username + "_cart.txt", ios::app);
        int cloth_prices, total_payment;
        user u;
        if (cloth_size == 's')
        {
            cloth_prices = 2000 * stock_quantity;
        }
        else if (cloth_size == 'm')
        {
            cloth_prices = 2500 * stock_quantity;
        }
        else if (cloth_size == 'l')
        {
            cloth_prices = 4000 * stock_quantity;
        }

        if (cartFile.is_open())
        {
            cartFile << "Cloth Name: " << cloth_name << "\n";
            cartFile << "Color: " << cloth_color << "\n";
            cartFile << "Size: " << cloth_size << "\n";

            if (cloth_prices >= 5000)
            {
                total_payment = u.silver_customer(cloth_prices);
            }
            else if (cloth_prices >= 3000 && cloth_prices < 5000)
            {
                total_payment = u.gold_customer(cloth_prices);
            }
            else if (cloth_prices < 3000)
            {
                total_payment = u.platinum_customer(cloth_prices);
            }
            cartFile << "Price: " << total_payment << "\n";

            cartFile << "Quantity: " << stock_quantity << "\n";
            cartFile << "-----------------------\n";
            cartFile.close();
        }
        else
        {
            cout << "Error opening file to save cart items!" << endl;
        }
    }
};

class female : public cloth
{
protected:
    int product_id;
    string cloth_name;
    string cloth_color;
    char cloth_size;
    long cloth_price;
    int stock_quantity;

public:
    void set_info() override
    {
        cout << " product id :";
        cin >> product_id;
        cout << "enter cloth name:  ";
        cin >> cloth_name;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size:  ";
        cin >> cloth_size;
        cout << "cloth price:  ";
        cin >> cloth_price;
        cout << " quantity of that cloth: ";
        cin >> stock_quantity;
    }
};
class male : public cloth
{
protected:
    int product_id;
    string cloth_name;
    string cloth_color;
    char cloth_size;
    long cloth_price;
    int stock_quantity;

public:
    void set_info() override
    {
        cloth::set_info();
    }
};
class children : public cloth
{
protected:
    int product_id;
    string cloth_name;
    string cloth_color;
    char cloth_size;
    long cloth_price;
    int stock_quantity;

public:
    void set_info()
    {
        cloth::set_info();
    }
};
class frocks : public female
{
protected:
    string fabric_type;
    string cloth_color;
    char cloth_size;
    long cloth_price;
    int stock_quantity;

public:
    frocks()
    {
    back:
        order o;
        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!           " << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;
            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\t Invalid qualities" << endl;
            frocks();
        }
    }
};
class shalwar_kameez : public female
{
protected:
    string fabric_type;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    shalwar_kameez()
    {
    back:
        order o;
        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!" << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;
            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\tInvalid qualities" << endl;
            shalwar_kameez();
        }
    }
};
class lehnga : public female
{
protected:
    string fabric_type;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    lehnga()
    {
    back:
        order o;
        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!             " << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;
            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\tInvalid qualities" << endl;
            lehnga();
        }
    }
};
class pent_coat : public male
{
protected:
    string fabric_type;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    pent_coat()
    {
    back:
        order o;
        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!           " << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;
            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\tInvalid qualities" << endl;
            pent_coat();
        }
    }
};
class pent_shirt : public male
{
protected:
    string fabric_type;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    pent_shirt()
    {
    back:
        order o;
        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!             " << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;
            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\tInvalid qualities" << endl;
            pent_shirt();
        }
    }
};
class skirt : public children
{
protected:
    string fabric_type;
    long cloth_price;
    string cloth_color;
    char cloth_size;
    int stock_quantity;

public:
    skirt()
    {
    back:
        order o;

        string Username;
        cout << "________________________Fabric Details___________________ ";

        cout << "fabric type:  ";
        cin >> fabric_type;
        cout << "color of cloth:  ";
        cin >> cloth_color;
        cout << "cloth size(l,m,s):  ";
        cin >> cloth_size;
        cout << "cloth price is 2000 for small 2500 for medium and 4000 for large.\nHave you agree with this price? ";
        int opt;
        cout << "\n 1.OK" << endl;
        cout << "\n 2.not ok" << endl;
        cin >> opt;
        if (opt == 1)
        {
            cout << " quantity of that cloth(<5): ";
            cin >> stock_quantity;
        }
        else
        {
            cout << "           OOPS Only these prices are availaible!             " << endl;
            goto back;
        }

        if (check_cloth_Exists(fabric_type, cloth_color, cloth_size))

        {
            cout << "\t\t exist cloth" << endl;

            int opt1;
            cout << "\t\t Do you want to ADD TO CART ?" << endl;

            cout << "\n 1.Yes" << endl;
            cout << "\n 2.Not(exit)" << endl;
            cin >> opt;
            if (opt == 1)
            {
                cout << "Enter your User_name: ";
                cin >> Username;
                o.save_Cart_Items_To_File(Username, fabric_type, cloth_color, cloth_size, stock_quantity);
            }
            else if (opt == 2)
            {
                exit(0);
            }
        }
        else
        {
            cout << "\t\tInvalid qualities" << endl;
            skirt();
        }
    }
};

class menuhandling
{
public:
    void menu()
    {
        cout << "Select a category:\n1. Male\n2. Female\n3. Children\n4. Exit Shop\n";
        int category, choice;
        cin >> category;

        cloth *ptr;

        switch (category)
        {
        case 1:
            cout << "Select a type:\n1. pent_coat\n2. shalwar_kameez\n3. pent_shirt\n";
            cin >> choice;
            if (choice == 1)
            {
                ptr = new pent_coat();
            }
            else if (choice == 2)
            {
                ptr = new shalwar_kameez();
            }
            else if (choice == 3)
            {
                ptr = new pent_shirt();
            }
            break;
        case 2:
            cout << "Select a type:\n1. frocks\n2. shalwar_kameez\n3. skirt\n 4. lehnga\n";
            cin >> choice;
            if (choice == 1)
            {
                ptr = new frocks();
            }
            else if (choice == 2)
            {
                ptr = new shalwar_kameez();
            }
            else if (choice == 3)
            {
                ptr = new skirt();
            }
            else if (choice == 4)
            {
                ptr = new lehnga();
            }
            break;

        case 3:

            cout << "Select a type:\n1. skirt\n2. shalwar_kameez\n3. pent_shirt\n";
            cin >> choice;
            if (choice == 1)
            {
                ptr = new skirt();
            }
            else if (choice == 2)
            {
                ptr = new shalwar_kameez();
            }
            else if (choice == 3)
            {
                ptr = new pent_shirt();
            }
            break;
        case 4:
            cout << "Thank You" << endl;
            exit(0); // it will end the program

        default:
            cout << "Invalid category choice. PLease select a valid choice\n";
            menu();
        }

        delete ptr;
    }
    void program_directions_handling()
    {
        usermanager um;
        int op;
        cout << "\n\t\t1. log in" << endl;
        cout << "\n\t\t2. sign up" << endl;
        cout << "\n\t\tEnter your choice : ";
        cin >> op;

        switch (op)
        {
        case 1:
            um.log_in_user();
            menu();
            break;
        case 2:
            um.registerUser();
            menu();
            break;
        default:
            exit(1); // Exit the program with an error code
        }
    }
    void handle_Order_Confirmation(order &o)
    {
        int confirmChoice;
        cout << "\nWould you like to confirm your order?\n1. Yes\n2. No\n";
        cin >> confirmChoice;

        if (confirmChoice == 1)
        {
            o.confirm_Payment();
            o.display();
        }
        else
        {
            cout << "\nOrder not confirmed. Thank you!\n";
        }
    }
};

int main()
{
    menuhandling menu;
    menu.program_directions_handling();
    int option;
    cout << "         ---------------------------------------------------------------------" << endl;
    cout << "\n\t\t\t\tADD TO CART OR SHOP NOW" << endl;
    cout << "       ----------------------------------------------------------------------" << endl;
    cout << "Enter 1 for shop more ,2 for order now , now 3  for Exit: " << endl;
    cin >> option;
    order o;
    string Username;
    switch (option)
    {
    case 1:
        menu.menu();
        break;
    case 2:

        o.get_data1();
        menu.handle_Order_Confirmation(o);

        break;

    default:
        exit(1);
    }
    cout << "       --------------------------------------------------------------------" << endl;
    cout << "\n\t\t\t\tTHANKS FOR SHOPPING" << endl;
    cout << "       --------------------------------------------------------------------" << endl;

    return 0;
}